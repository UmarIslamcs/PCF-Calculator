/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    sampleProperty: ComponentFramework.PropertyTypes.StringProperty;
    scientific: ComponentFramework.PropertyTypes.TwoOptionsProperty;
}
export interface IOutputs {
    sampleProperty?: string;
    scientific?: boolean;
}
