// import * as React from 'react';
// import { useState } from 'react';

// const Calculator = () => {
//   const [data, setData] = useState("");
//   const [showHide, setShowHide] = useState(false);

//   const getValue = (event: any) => {
//     setData(data.concat(event.target.value));
//   };

//   const eql = () => {
//     setData(eval(data).toString());
//   };

//   const back = () => {
//     setData(data.slice(0, -1));
//   };

//   const clear = () => {
//     setData("");
//   };

//   const hideFunction = () => {
//     setShowHide(!showHide);
//   };

//   const sinFun = () => {
//       const data1 = parseFloat(data);  
//       const sin = Math.sin(data1);
//       setData(sin.toString());  
//   };
//   const cosFun = () => {
//       const data1 = parseFloat(data);  
//       const cos = Math.cos(data1);
//       setData(cos.toString());   
//   };
//   const tanFun = () => {
//       const data1 = parseFloat(data);  
//       const tan = Math.tan(data1);
//       setData(tan.toString());  
//   };
//   const logFun = () => {
//       const data1 = parseFloat(data);  
//       const log = Math.log(data1);
//       setData(log.toString());  
//   };

//   return (
//     <>
//       <div className='container'>
//         <div>
//           <input placeholder='0' value={data} />

//           <button onClick={getValue} value="(">(</button>
//           <button onClick={getValue} value=")">)</button>
//           <button onClick={getValue} value="%">%</button>
//           <button onClick={clear} style={{ backgroundColor: 'tomato' }}>Ac</button>

//           <button onClick={getValue} value="7">7</button>
//           <button onClick={getValue} value="8">8</button>
//           <button onClick={getValue} value="9">9</button>
//           <button onClick={back} style={{ backgroundColor: 'tomato' }}>Back</button>
          
          

//           <button onClick={getValue} value="4">4</button>
//           <button onClick={getValue} value="5">5</button>
//           <button onClick={getValue} value="6">6</button>
//           <button onClick={getValue} value="-">-</button>
          
          

//           <button onClick={getValue} value="1">1</button>
//           <button onClick={getValue} value="2">2</button>
//           <button onClick={getValue} value="3">3</button>
//           <button onClick={getValue} value="+">+</button>

//           <button onClick={getValue} value="0">0</button>
//           <button onClick={getValue} value="/">/</button>
//           <button onClick={getValue} value="*">*</button>
//           <button onClick={eql} style={{ backgroundColor: 'lightgreen' }}>=</button>
          
          

//           {showHide && <button onClick={sinFun}>Sin</button>}
//           {showHide && <button onClick={cosFun}>Cos</button>}
//           {showHide && <button onClick={tanFun}>Tan</button>}
//           {showHide && <button onClick={logFun}>Log</button>}
//           <button onClick={hideFunction}  style={{ backgroundColor: 'lightblue' }}>Sci</button>

//         </div>
//       </div>
//     </>
//   );
// };

// export default Calculator;


import * as React from 'react';
import { useState } from 'react';

const Calculator = ({ scientific }: { scientific: boolean }) => {
  const [data, setData] = useState("");

  const getValue = (event: any) => {
    setData(data.concat(event.target.value));
  };

  const eql = () => {
    setData(eval(data).toString());
  };

  const back = () => {
    setData(data.slice(0, -1));
  };

  const clear = () => {
    setData("");
  };

  const sinFun = () => {
    const data1 = parseFloat(data);
    const sin = Math.sin(data1);
    setData(sin.toString());
  };

  const cosFun = () => {
    const data1 = parseFloat(data);
    const cos = Math.cos(data1);
    setData(cos.toString());
  };

  const tanFun = () => {
    const data1 = parseFloat(data);
    const tan = Math.tan(data1);
    setData(tan.toString());
  };

  const logFun = () => {
    const data1 = parseFloat(data);
    const log = Math.log(data1);
    setData(log.toString());
  };

  return (
    <div className="container">
      <div>
        <input placeholder="0" value={data} />
        <button onClick={getValue} value="(">(</button>
        <button onClick={getValue} value=")">)</button>
        <button onClick={getValue} value="%">%</button>
        <button onClick={clear} style={{ backgroundColor: 'tomato' }}>Ac</button>

        <button onClick={getValue} value="7">7</button>
        <button onClick={getValue} value="8">8</button>
        <button onClick={getValue} value="9">9</button>
        <button onClick={back} style={{ backgroundColor: 'tomato' }}>Back</button>

        <button onClick={getValue} value="4">4</button>
        <button onClick={getValue} value="5">5</button>
        <button onClick={getValue} value="6">6</button>
        <button onClick={getValue} value="-">-</button>

        <button onClick={getValue} value="1">1</button>
        <button onClick={getValue} value="2">2</button>
        <button onClick={getValue} value="3">3</button>
        <button onClick={getValue} value="+">+</button>

        <button onClick={getValue} value="0">0</button>
        <button onClick={getValue} value="/">/</button>
        <button onClick={getValue} value="*">*</button>
        <button onClick={getValue} value=".">.</button>
       

         
        {scientific && <button onClick={sinFun}>Sin</button>}
        {scientific && <button onClick={cosFun}>Cos</button>}
        {scientific && <button onClick={tanFun}>Tan</button>}
        {scientific && <button onClick={logFun}>Log</button>}
        <button onClick={eql} style={{ backgroundColor: 'lightgreen', alignSelf :'center' }}>=</button>
      </div>
    </div>
  );
};

export default Calculator;
