import * as ReactDOM from "react-dom";
import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import Calculator from "./src/Components/Calculator";


export class Calculate implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    _container: HTMLDivElement;
    _context: ComponentFramework.Context<IInputs>;

    constructor() {}

    public init(context: ComponentFramework.Context<IInputs>, notifyOutputChanged: () => void, state: ComponentFramework.Dictionary, container: HTMLDivElement): void {
        this._container = container;
        this._context = context;

        
        this.renderComponent();
    }




    public updateView(context: ComponentFramework.Context<IInputs>): void {
         
        this._context = context;
        this.renderComponent();
    }

    private renderComponent() {
        
        const isScientificEnabled = this._context.parameters.scientific.raw ; 

        ReactDOM.render(
            React.createElement(Calculator, { scientific: isScientificEnabled }),
            this._container
        );
    }





    
    public getOutputs(): IOutputs {
        return {};  
    }

    public destroy(): void {
         
    }
}
